<?php
/*
 * [ GITHUB UPLOAD & EXTRACTOR ]
 * Converted from JavaScript to PHP
 * Original source: https://whatsapp.com/channel/0029VbAo3iNAjPXTxx0Luv33
 * 
 * Fitur: Upload file ZIP & ekstrak langsung ke GitHub via Token
 * Support: Semua file (binary & text), struktur folder dipertahankan
 */

error_reporting(0);
ini_set('display_errors', '0');

header('Content-Type: application/json; charset=utf-8');

$credit = [
    'creator' => 'Gunz',
    'version' => '1.1'
];

// ========== FUNGSI HELPER ==========

function bufferToBase64($buffer) {
    return base64_encode($buffer);
}

function delay($ms) {
    usleep($ms * 1000);
}

/**
 * Cek apakah entri ZIP adalah folder
 */
function isZipFolder($entryName) {
    return substr($entryName, -1) === '/';
}

/**
 * Normalisasi path folder (hapus slash di akhir)
 */
function normalizeFolderPath($path) {
    return rtrim($path, '/');
}

// ========== FUNGSI GITHUB API ==========

function uploadToGitHub($token, $owner, $repo, $filePath, $content, $maxRetries = 3) {
    $encodedPath = implode('/', array_map('rawurlencode', explode('/', $filePath)));
    $url = "https://api.github.com/repos/{$owner}/{$repo}/contents/{$encodedPath}";
    
    $attempt = 0;
    while ($attempt < $maxRetries) {
        try {
            // Cek SHA (file existing)
            $sha = null;
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: token ' . $token,
                'User-Agent: PHP-GitHub-Uploader'
            ]);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200) {
                $data = json_decode($response, true);
                if ($data && isset($data['sha'])) {
                    $sha = $data['sha'];
                }
            }
            
            // Upload/Update
            $data = [
                'message' => $sha ? "Update {$filePath}" : "Add {$filePath}",
                'content' => $content
            ];
            if ($sha) {
                $data['sha'] = $sha;
            }
            
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: token ' . $token,
                'Content-Type: application/json',
                'User-Agent: PHP-GitHub-Uploader'
            ]);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200 || $httpCode === 201) {
                return json_decode($response, true);
            }
            
            if ($httpCode === 403) {
                $attempt++;
                delay(2000 * $attempt);
                continue;
            }
            
            throw new Exception("HTTP {$httpCode}");
            
        } catch (Exception $e) {
            $attempt++;
            if ($attempt >= $maxRetries) {
                throw new Exception("Gagal upload {$filePath}: " . $e->getMessage());
            }
            delay(1000);
        }
    }
}

function createRepository($token, $owner, $repoName, $isPrivate = false) {
    $url = 'https://api.github.com/user/repos';
    $data = [
        'name' => $repoName,
        'private' => $isPrivate,
        'auto_init' => false
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: token ' . $token,
        'Content-Type: application/json',
        'User-Agent: PHP-GitHub-Uploader'
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200 && $httpCode !== 201) {
        throw new Exception("Gagal membuat repository: HTTP {$httpCode}");
    }
    
    return json_decode($response, true);
}

function checkRepository($token, $owner, $repoName) {
    $url = "https://api.github.com/repos/{$owner}/{$repoName}";
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: token ' . $token,
        'User-Agent: PHP-GitHub-Uploader'
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return $httpCode === 200;
}

// ========== PROSES ZIP ==========

function processZipFile($zipBuffer, $token, $owner, $repo, $includeEmptyFolders = false) {
    $zip = new ZipArchive();
    $tempZip = tempnam(sys_get_temp_dir(), 'zip_');
    file_put_contents($tempZip, $zipBuffer);
    
    if ($zip->open($tempZip) !== true) {
        unlink($tempZip);
        throw new Exception('Gagal membuka file ZIP');
    }
    
    // ========== KUMPULKAN SEMUA FILE (TERMASUK DALAM FOLDER) ==========
    $fileList = [];
    $folderList = [];
    $totalEntries = $zip->numFiles;
    
    for ($i = 0; $i < $totalEntries; $i++) {
        $stat = $zip->statIndex($i);
        if ($stat === false) continue;
        
        $entryName = $stat['name'];
        
        // Skip entry yang tidak valid
        if (empty($entryName)) continue;
        
        // Deteksi folder (berakhiran slash)
        if (isZipFolder($entryName)) {
            $folderPath = normalizeFolderPath($entryName);
            if (!empty($folderPath)) {
                $folderList[] = $folderPath;
            }
            continue;
        }
        
        // Ini file — tambahkan ke list
        // Normalisasi path: hilangkan leading slash dan backslash
        $cleanPath = ltrim(str_replace('\\', '/', $entryName), '/');
        
        // Skip file tersembunyi sistem
        if (strpos($cleanPath, '__MACOSX/') === 0 || basename($cleanPath) === '.DS_Store') {
            continue;
        }
        
        $fileList[] = [
            'name' => $cleanPath,
            'index' => $i,
            'size' => $stat['size']
        ];
    }
    
    if (empty($fileList) && empty($folderList)) {
        $zip->close();
        unlink($tempZip);
        throw new Exception('Tidak ada file yang ditemukan dalam ZIP');
    }
    
    $total = count($fileList);
    $uploaded = 0;
    $failed = 0;
    $results = [];
    
    // ========== UPLOAD FILE (TERMASUK DALAM SUBFOLDER) ==========
    foreach ($fileList as $index => $file) {
        try {
            $filePath = $file['name'];
            
            // Ambil konten file
            $content = $zip->getFromIndex($file['index']);
            if ($content === false) {
                throw new Exception('Gagal membaca konten file');
            }
            
            // Encode ke base64 (berlaku untuk semua file: teks, binary, gambar, dll)
            $base64Content = bufferToBase64($content);
            
            // Upload ke GitHub — path sudah termasuk folder jika ada
            uploadToGitHub($token, $owner, $repo, $filePath, $base64Content);
            
            $uploaded++;
            $results[] = [
                'path' => $filePath,
                'size' => $file['size'],
                'status' => 'success'
            ];
            
            if (($index + 1) % 5 === 0 || $index === $total - 1) {
                error_log("Progress: {$uploaded}/{$total} file diupload...");
            }
            
            delay(200); // Delay 200ms antar upload
            
        } catch (Exception $e) {
            $failed++;
            $results[] = [
                'path' => $file['name'],
                'status' => 'failed',
                'error' => $e->getMessage()
            ];
        }
    }
    
    $zip->close();
    unlink($tempZip);
    
    return [
        'uploaded' => $uploaded,
        'failed' => $failed,
        'total' => $total,
        'folders_detected' => count($folderList),
        'folders' => $folderList,
        'results' => $results
    ];
}

// ========== HANDLE REQUEST ==========

try {
    // Validasi parameter
    if (!isset($_POST['token']) || !isset($_POST['owner']) || !isset($_POST['repo']) || !isset($_POST['mode'])) {
        throw new Exception(
            "Parameter wajib:\n" .
            "token - GitHub Personal Access Token (repo scope)\n" .
            "owner - Username GitHub\n" .
            "repo - Nama repository\n" .
            "mode - new (buat baru) atau existing (pakai yg ada)\n\n" .
            "Contoh: token=ghp_xxxxx&owner=jerexd&repo=my-repo&mode=new"
        );
    }
    
    $token = trim($_POST['token']);
    $owner = trim($_POST['owner']);
    $repoName = trim($_POST['repo']);
    $repoType = trim($_POST['mode']);
    
    // Validasi token format
    if (!preg_match('/^ghp_[a-zA-Z0-9]{36}$/', $token)) {
        throw new Exception('Format token GitHub tidak valid. Harus dimulai dengan ghp_');
    }
    
    if ($repoType !== 'new' && $repoType !== 'existing') {
        throw new Exception("Mode harus 'new' atau 'existing'!");
    }
    
    // Cek file ZIP
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('File ZIP wajib diupload');
    }
    
    $file = $_FILES['file'];
    $fileTmp = $file['tmp_name'];
    $fileName = $file['name'];
    $fileSize = $file['size'];
    
    // Validasi file ZIP (longgar — cukup ekstensi .zip)
    if (strtolower(substr($fileName, -4)) !== '.zip') {
        // Cek juga via mime
        $fileMime = function_exists('mime_content_type') ? @mime_content_type($fileTmp) : '';
        if (strpos($fileMime, 'zip') === false && strpos($fileMime, 'octet-stream') === false) {
            throw new Exception('File harus berformat ZIP');
        }
    }
    
    $maxSize = 50 * 1024 * 1024; // 50MB
    if ($fileSize > $maxSize) {
        throw new Exception('File ZIP terlalu besar (max 50MB)');
    }
    
    $zipBuffer = file_get_contents($fileTmp);
    if ($zipBuffer === false) {
        throw new Exception('Gagal membaca file ZIP');
    }
    
    $zipSizeMB = number_format($fileSize / 1024 / 1024, 2);
    
    // ========== PROSES UPLOAD ==========
    
    $repo = $repoName;
    
    // Create atau cek repository
    if ($repoType === 'new') {
        try {
            createRepository($token, $owner, $repoName, false);
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'already exists') !== false) {
                throw new Exception("Repository {$repoName} sudah ada, gunakan mode 'existing'");
            }
            throw $e;
        }
        delay(2000); // Delay 2 detik setelah create repo
    } else {
        if (!checkRepository($token, $owner, $repoName)) {
            throw new Exception("Repository {$repoName} tidak ditemukan atau token tidak memiliki akses");
        }
    }
    
    // Proses ZIP — upload semua file termasuk dalam folder
    $result = processZipFile($zipBuffer, $token, $owner, $repo, false);
    
    // ========== RESPONSE ==========
    
    $response = array_merge($credit, [
        'status' => true,
        'result' => [
            'repository' => "https://github.com/{$owner}/{$repo}",
            'mode' => $repoType,
            'total_files' => $result['total'],
            'uploaded' => $result['uploaded'],
            'failed' => $result['failed'],
            'folders_detected' => $result['folders_detected'],
            'success_rate' => $result['total'] > 0 ? round(($result['uploaded'] / $result['total']) * 100, 2) . '%' : '0%',
            'details' => $result['results']
        ]
    ]);
    
    if ($result['failed'] > 0) {
        $failedFiles = array_slice(array_filter($result['results'], function($r) {
            return $r['status'] === 'failed';
        }), 0, 5);
        
        $response['warnings'] = $result['failed'] . ' file gagal diupload';
        $response['failed_files'] = array_map(function($f) {
            return $f['path'] . ' (' . ($f['error'] ?? 'Unknown error') . ')';
        }, $failedFiles);
        
        if ($result['failed'] > 5) {
            $response['failed_files'][] = "dan " . ($result['failed'] - 5) . " file lainnya";
        }
    } else {
        $response['message'] = '✅ Semua file berhasil diupload!';
    }
    
    echo json_encode($response, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => $e->getMessage(),
        'error_code' => $e->getCode()
    ]), JSON_PRETTY_PRINT);
}
?>