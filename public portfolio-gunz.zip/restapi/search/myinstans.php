<?php
error_reporting(0);
ini_set('display_errors', '0');
// Deskripsi: Gunz API - Myinstants Search Sounds
// Contoh: {"q": "vine boom", "page": "1"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param q Text Input - Kata kunci pencarian suara (contoh: vine boom, bruh, anime wow, fart)
// @param page Text Input - Halaman hasil pencarian (default: 1)

header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");

$q    = trim($_GET['q'] ?? '');
$page = intval($_GET['page'] ?? 1);

if ($page < 1) $page = 1;
if ($page > 50) $page = 50;

if ($q === '') {
    echo json_encode([
        'creator' => 'Gunz',
        'status'  => false,
        'message' => 'Gunakan ?q=vine+boom',
        'example' => '?q=vine+boom&page=1'
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// ---------- Fetch dengan proteksi anti-blokir ----------
function fetchPage($url) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_ENCODING       => '',
        CURLOPT_HTTPHEADER     => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.9,id;q=0.8',
            'Referer: https://www.myinstants.com/',
            'Sec-Fetch-Dest: document',
            'Sec-Fetch-Mode: navigate',
            'Sec-Fetch-Site: same-origin',
            'Upgrade-Insecure-Requests: 1',
            'Cache-Control: max-age=0',
            'Connection: keep-alive'
        ],
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ]);
    $html = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($code === 403 || $code === 429) return false; // diblokir / rate limit
    if ($code === 200 && $html) return $html;
    return false;
}

$url = 'https://www.myinstants.com/en/search/?name=' . urlencode($q) . '&page=' . $page;
$html = fetchPage($url);

if (!$html) {
    echo json_encode([
        'creator' => 'Gunz',
        'status'  => false,
        'message' => 'Gagal scrape halaman Myinstants (kemungkinan diblokir Cloudflare / rate limit)'
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// ---------- Parse ----------
$sounds = [];
$seen   = [];

// Split per blok <div class="instant">
$parts = preg_split('/<div class="instant"/', $html);
array_shift($parts);

foreach ($parts as $block) {
    $block = substr($block, 0, 2000);

    // --- Title + URL halaman ---
    $title   = '';
    $pageUrl = '';

    if (preg_match('/<a[^>]*class="[^"]*instant-link[^"]*"[^>]*href="([^"]+)"[^>]*>([^<]+)<\/a>/i', $block, $m)) {
        $pageUrl = $m[1];
        $title   = trim(html_entity_decode($m[2], ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    } elseif (preg_match('/<a[^>]*href="([^"]+)"[^>]*class="[^"]*instant-link[^"]*"[^>]*>([^<]+)<\/a>/i', $block, $m)) {
        $pageUrl = $m[1];
        $title   = trim(html_entity_decode($m[2], ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    }

    if (!$title || !$pageUrl) continue;

    // --- MP3 URL ---
    $mp3 = '';

    if (preg_match('/onclick="play\(\s*[\'"]([^\'"]+\.mp3)[\'"]/i', $block, $m)) {
        $mp3 = $m[1];
    } elseif (preg_match('/data-url="([^"]+\.mp3)"/i', $block, $m)) {
        $mp3 = $m[1];
    } elseif (preg_match('/src="([^"]+\.mp3)"/i', $block, $m)) {
        $mp3 = $m[1];
    }

    if (!$mp3) continue;

    // Normalisasi URL
    if (strpos($mp3, 'http') !== 0) {
        $mp3 = 'https://www.myinstants.com' . (strpos($mp3, '/') === 0 ? '' : '/') . $mp3;
    }
    if (strpos($pageUrl, 'http') !== 0) {
        $pageUrl = 'https://www.myinstants.com' . (strpos($pageUrl, '/') === 0 ? '' : '/') . $pageUrl;
    }

    if (isset($seen[$mp3])) continue;
    $seen[$mp3] = true;

    $sounds[] = [
        'title' => $title,
        'url'   => $pageUrl,
        'mp3'   => $mp3
    ];
}

// ---------- Fallback global regex ----------
if (empty($sounds)) {
    if (preg_match_all('/<a[^>]*href="(\/en\/instant\/[^"]+)"[^>]*class="[^"]*instant-link[^"]*"[^>]*>([^<]+)<\/a>/i', $html, $m, PREG_SET_ORDER)) {
        foreach ($m as $item) {
            $sounds[] = [
                'title' => trim(html_entity_decode($item[2], ENT_QUOTES | ENT_HTML5, 'UTF-8')),
                'url'   => 'https://www.myinstants.com' . $item[1],
                'mp3'   => ''
            ];
        }
    }
}

// ---------- Response ----------
echo json_encode([
    'creator' => 'Gunz',
    'status'  => true,
    'input'   => [
        'q'    => $q,
        'page' => $page
    ],
    'result'  => [
        'keyword' => $q,
        'page'    => $page,
        'count'   => count($sounds),
        'sounds'  => $sounds
    ]
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);