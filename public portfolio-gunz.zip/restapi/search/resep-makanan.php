<?php
error_reporting(0);
ini_set('display_errors', '0');
// Deskripsi: Cookpad Indonesia Recipe Scraper
// Contoh: {"q": "rendang", "page": 1}
// @param page (1|2|3|4|5) Jumlah halaman (default: 1)

header('Content-Type: application/json; charset=utf-8');
set_time_limit(60);

$query = $_GET['q'] ?? '';
$maxPages = intval($_GET['page'] ?? 1);

$allowedPages = [1, 2, 3, 4, 5];
if (!in_array($maxPages, $allowedPages)) {
    $maxPages = 1;
}

if (empty($query)) {
    echo json_encode([
        'status' => false,
        'creator' => 'Gunz',
        'message' => 'Parameter q wajib diisi'
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// ---------- Fetch ----------
function fetchUrl($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
    ]);
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($http_code === 200 && !empty($response)) return $response;
    return false;
}

// ---------- Helpers ----------
function stripHtml($html) {
    $text = preg_replace('/<[^>]+>/', ' ', $html);
    $text = str_replace(
        ['&amp;', '&lt;', '&gt;', '&quot;', '&#39;', '&nbsp;'],
        ['&', '<', '>', '"', "'", ' '],
        $text
    );
    $text = preg_replace('/\s+/', ' ', $text);
    return trim($text);
}

// Ambil __NEXT_DATA__ JSON
function parseNextData($html) {
    if (preg_match('/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/s', $html, $m)) {
        $json = json_decode($m[1], true);
        if (json_last_error() === JSON_ERROR_NONE) return $json;
    }
    return null;
}

// Cari array resep secara rekursif di dalam JSON
function findRecipesDeep($data, &$found = []) {
    if (!is_array($data)) return;
    // Heuristik: node yg punya 'id' & ('title' atau 'name')
    if (isset($data['id']) && (isset($data['title']) || isset($data['name']))) {
        $found[] = $data;
    }
    foreach ($data as $v) {
        if (is_array($v)) findRecipesDeep($v, $found);
    }
}

// Normalisasi 1 resep dari JSON
function normalizeRecipe($r) {
    $id    = $r['id'] ?? '';
    $title = $r['title'] ?? ($r['name'] ?? '');
    if (!$id || !$title) return null;

    $url = $r['url'] ?? '';
    if ($url && strpos($url, 'http') !== 0) {
        $url = 'https://cookpad.com' . $url;
    }
    if (!$url) $url = "https://cookpad.com/id/resep/{$id}";

    // Ingredients
    $ingredients = [];
    foreach (['ingredients', 'ingredient_list', 'recipe_ingredients'] as $key) {
        if (!empty($r[$key]) && is_array($r[$key])) {
            foreach ($r[$key] as $ing) {
                if (is_string($ing)) $ingredients[] = $ing;
                elseif (is_array($ing)) {
                    if (isset($ing['name'])) $ingredients[] = trim(($ing['name'] ?? '') . ' ' . ($ing['quantity'] ?? ''));
                    elseif (isset($ing['text'])) $ingredients[] = $ing['text'];
                }
            }
            if ($ingredients) break;
        }
    }

    // Image
    $image = '';
    foreach (['image_url', 'image', 'photo', 'thumbnail'] as $key) {
        if (!empty($r[$key]) && is_string($r[$key])) { $image = $r[$key]; break; }
        if (!empty($r[$key]['url'])) { $image = $r[$key]['url']; break; }
    }

    // Time
    $time = $r['cooking_time'] ?? ($r['time'] ?? ($r['duration'] ?? ''));

    // Servings
    $servings = $r['servings'] ?? ($r['yield'] ?? '');

    // Chef
    $chef = '';
    if (isset($r['author']['name'])) $chef = $r['author']['name'];
    elseif (isset($r['user']['name'])) $chef = $r['user']['name'];
    elseif (isset($r['chef'])) $chef = is_array($r['chef']) ? ($r['chef']['name'] ?? '') : $r['chef'];

    return [
        'id' => (string)$id,
        'title' => $title,
        'url' => $url,
        'chef' => $chef,
        'time' => is_array($time) ? ($time['text'] ?? '') : (string)$time,
        'servings' => is_array($servings) ? ($servings['text'] ?? '') : (string)$servings,
        'ingredients' => array_values($ingredients),
        'image' => $image
    ];
}

// ---------- Fallback regex HTML ----------
function parseRecipesHtml($html) {
    $recipes = [];
    // Cari blok resep berdasarkan struktur cookpad id modern
    if (preg_match_all('/<li[^>]*id="recipe_(\d+)"[^>]*>(.*?)<\/li>/s', $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $id = $m[1];
            $part = $m[2];

            preg_match('/href="(\/id\/resep\/\d+[^"]*)"/', $part, $urlM);
            $url = $urlM ? 'https://cookpad.com' . $urlM[1] : "https://cookpad.com/id/resep/{$id}";

            preg_match('/block-link__main[^>]*>([\s\S]*?)<\/a>/', $part, $titleM);
            $title = $titleM ? stripHtml($titleM[1]) : '';
            if (!$title) continue;

            preg_match('/src="(https:\/\/img-global\.cpcdn\.com\/[^"]+)"/', $part, $imgM);
            $image = $imgM[1] ?? '';

            preg_match_all('/class="[^"]*line-clamp-2[^"]*"[^>]*>([\s\S]*?)<\/div>/', $part, $ingM);
            $ingredients = [];
            if (!empty($ingM[1])) {
                foreach ($ingM[1] as $ing) {
                    $t = stripHtml($ing);
                    if ($t) $ingredients[] = $t;
                }
            }

            preg_match('/mise-icon-time[\s\S]*?mise-icon-text">(.*?)<\/span>/', $part, $timeM);
            preg_match('/mise-icon-user[\s\S]*?mise-icon-text">(.*?)<\/span>/', $part, $servM);

            $recipes[] = [
                'id' => $id,
                'title' => $title,
                'url' => $url,
                'chef' => '',
                'time' => $timeM ? stripHtml($timeM[1]) : '',
                'servings' => $servM ? stripHtml($servM[1]) : '',
                'ingredients' => $ingredients,
                'image' => $image
            ];
        }
    }
    return $recipes;
}

// Total hasil (angka Indonesia pakai titik ribuan)
function parseTotal($html) {
    if (preg_match('/<h1[^>]*>.*?<\/h1>\s*<[^>]*>\(([\d.]+)\)/s', $html, $m)) {
        return intval(str_replace('.', '', $m[1]));
    }
    if (preg_match('/\(([\d.]+)\)/', $html, $m)) {
        return intval(str_replace('.', '', $m[1]));
    }
    return 0;
}

// ---------- Main ----------
$encoded = urlencode($query);
$allRecipes = [];
$meta = ['total' => 0];

for ($page = 1; $page <= $maxPages; $page++) {
    $params = http_build_query([
        'country' => 'ID',
        'event' => 'search.filtered_query',
        'exclude_premium_recipes' => 'true',
        'excluded_keywords' => '',
        'language' => 'id',
        'order' => 'recent',
        'page' => $page
    ]);
    $url = "https://cookpad.com/id/cari/{$encoded}?{$params}";

    $html = fetchUrl($url);
    if (!$html) continue;

    if ($page === 1) {
        $meta['total'] = parseTotal($html);
    }

    $recipes = [];
    $nextData = parseNextData($html);
    if ($nextData) {
        $found = [];
        findRecipesDeep($nextData, $found);
        foreach ($found as $r) {
            $n = normalizeRecipe($r);
            if ($n) $recipes[] = $n;
        }
    }

    // Fallback kalau JSON tidak menghasilkan
    if (empty($recipes)) {
        $recipes = parseRecipesHtml($html);
    }

    // Dedup berdasarkan id
    foreach ($recipes as $r) {
        if (!isset($allRecipes[$r['id']])) {
            $allRecipes[$r['id']] = $r;
        }
    }

    if ($page < $maxPages) sleep(1);
}

$allRecipes = array_values($allRecipes);

echo json_encode([
    'creator' => 'Gunz',
    'status' => true,
    'result' => [
        'query' => $query,
        'total' => $meta['total'],
        'pages_scraped' => $maxPages,
        'count' => count($allRecipes),
        'recipes' => $allRecipes
    ]
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);