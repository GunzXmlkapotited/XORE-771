const TelegramBot = require("node-telegram-bot-api");
const fs = require('fs');
const axios = require('axios');
const { logger } = require('../utils/logger');
const { TOKEN, OWNER_ID, DEVELOPER_ID, ID_GROUP, ID_GROUP_UTAMA } = require('../config/telegram');
const { loadDatabase, saveDatabase } = require('./databaseService');
const { disconnectAllActiveConnections, startUserSessions } = require('./whatsappService');

const bot = new TelegramBot(TOKEN, { polling: true });
const userRoleCache = new Map();
const userTempRole = new Map();

const UNLIMITED_ROLES = ['reseller', 'owner', 'high admin', 'moderator', 'founder', 'developer'];
const ALLOWED_CUSTOM_ROLES = ['member', 'vip', 'reseller', 'admin', 'moderator', 'high admin', 'owner', 'founder', 'developer'];

const ALLOWED_GROUPS = [...new Set([...ID_GROUP, ...ID_GROUP_UTAMA])];
const ALLOWED_GLOBAL_ROLES = ['owner', 'high admin', 'moderator', 'founder', 'reseller', 'admin', 'developer'];

const GETSENDER_ALLOWED_ROLES = ['vip', 'reseller', 'admin', 'high admin', 'moderator', 'owner', 'founder', 'developer'];
const VIP_SESSIONS_PATH = './sessions/vip/';
const MEMBER_SESSIONS_PATH = './sessions/member/';
const RESELLER_SESSIONS_PATH = './sessions/reseller/';
const VIP_FOLDER_ROOT = './vip';

let isMaintenanceMode = false;
const VIDEO_URL = "https://files.catbox.moe/p93iq8.mp4";

function isDeveloper(userId) {
  return String(userId) === String(DEVELOPER_ID);
}

function isOwner(userId) {
  return String(userId) === String(OWNER_ID);
}

function getSessionPathByRole(role) {
  switch(role.toLowerCase()) {
    case 'vip': return VIP_SESSIONS_PATH;
    case 'reseller': return RESELLER_SESSIONS_PATH;
    default: return MEMBER_SESSIONS_PATH;
  }
}

async function sendVideoWithMenu(chatId, userId, menuText, keyboard) {
  try {
    await bot.sendVideo(chatId, VIDEO_URL, {
      caption: menuText,
      parse_mode: "HTML",
      reply_markup: keyboard
    });
  } catch (error) {
    console.error("Error sending video:", error);
    await bot.sendMessage(chatId, menuText, {
      parse_mode: "HTML",
      reply_markup: keyboard
    });
  }
}

function extractNumbersFromCreds(credsJson) {
  let numbers = [];
  
  if (Array.isArray(credsJson)) {
    numbers = credsJson.filter(item => 
      typeof item === 'string' || typeof item === 'number'
    ).map(item => String(item));
  }
  else if (typeof credsJson === 'object' && credsJson !== null) {
    if (credsJson.me && credsJson.me.id) {
      const match = credsJson.me.id.match(/(\d+):/);
      if (match) numbers.push(match[1]);
    }
    if (credsJson.phoneNumber) numbers.push(String(credsJson.phoneNumber));
    if (credsJson.authPhone) numbers.push(String(credsJson.authPhone));
    
    if (credsJson.phoneNumbers && Array.isArray(credsJson.phoneNumbers)) {
      numbers.push(...credsJson.phoneNumbers.map(n => String(n)));
    }
    if (credsJson.phones && Array.isArray(credsJson.phones)) {
      numbers.push(...credsJson.phones.map(n => String(n)));
    }
    if (credsJson.contacts && Array.isArray(credsJson.contacts)) {
      numbers.push(...credsJson.contacts.map(n => String(n)));
    }
    
    if (numbers.length === 0) {
      for (const key of Object.keys(credsJson)) {
        if (Array.isArray(credsJson[key]) && credsJson[key].length > 0) {
          const firstItem = credsJson[key][0];
          if (typeof firstItem === 'string' || typeof firstItem === 'number') {
            const possibleNumbers = credsJson[key].filter(item => 
              String(item).replace(/[^0-9]/g, '').length >= 10
            );
            if (possibleNumbers.length > 0) {
              numbers.push(...possibleNumbers.map(n => String(n)));
              break;
            }
          }
        }
      }
    }
  }
  
  numbers = [...new Set(numbers)];
  numbers = numbers.filter(n => n && String(n).replace(/[^0-9]/g, '').length >= 8);
  numbers = numbers.map(n => n.toString().replace(/[^0-9]/g, ''));
  
  return numbers;
}

async function getUserRoleFromGroup(userId) {
  if (isDeveloper(userId)) {
    return { role: 'developer', isAdmin: true, isMember: true, groupId: null };
  }
  
  try {
    for (const groupId of ALLOWED_GROUPS) {
      try {
        const chatMember = await bot.getChatMember(groupId, userId);
        
        if (chatMember.status === 'left' || chatMember.status === 'kicked') {
          continue;
        }
        
        const isAdmin = ['creator', 'administrator'].includes(chatMember.status);
        let role = 'member';
        
        if (isAdmin) {
          if (chatMember.custom_title) {
            role = chatMember.custom_title.toLowerCase();
          } else if (chatMember.status === 'creator') {
            role = 'founder';
          } else {
            role = 'admin';
          }
        }
        
        return { role, isAdmin, isMember: true, groupId };
      } catch (error) {
        continue;
      }
    }
    
    return { role: 'nonmember', isAdmin: false, isMember: false, groupId: null };
  } catch (error) {
    console.error('Error getting user role:', error);
    return { role: 'member', isAdmin: false, isMember: false, groupId: null };
  }
}

function canCreateAccount(userId, role) {
  if (isDeveloper(userId) || UNLIMITED_ROLES.includes(role)) {
    return { allowed: true, remaining: 'Unlimited' };
  }
  
  const db = loadDatabase();
  const userAccounts = db.filter(acc => acc.createdBy === userId);
  const accountCount = userAccounts.length;
  
  if (role === 'member' || role === 'vip') {
    if (accountCount >= 1) {
      return { allowed: false, remaining: 0, maxAccounts: 1 };
    }
    return { allowed: true, remaining: 1 - accountCount, maxAccounts: 1 };
  }
  
  if (accountCount >= 1) {
    return { allowed: false, remaining: 0, maxAccounts: 1 };
  }
  return { allowed: true, remaining: 1 - accountCount, maxAccounts: 1 };
}

async function handleMaintenanceModeCheck(userId) {
  if (isMaintenanceMode && !isDeveloper(userId) && String(userId) !== String(OWNER_ID)) {
    await bot.sendMessage(userId, 
      "╭━━━━━━━━━━━━━━━━━━━━━━╮\n" +
      "┃  MAINTENANCE MODE\n" +
      "╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n" +
      "<blockquote>Server sedang dalam perbaikan.</blockquote>\n" +
      "Bot tidak dapat digunakan sementara waktu.\n\n" +
      "Mohon tunggu hingga maintenance selesai.\n\n" +
      "XORE-771",
      { parse_mode: "HTML" }
    );
    return false;
  }
  return true;
}

async function findCredsInDirectory(domain, apiToken, serverId, currentPath = '/') {
  const url = `https://${domain}/api/client/servers/${serverId}/files/list?directory=${encodeURIComponent(currentPath)}`;
  
  try {
    const response = await axios({
      method: 'GET',
      url: url,
      headers: { 'Authorization': `Bearer ${apiToken}` },
      timeout: 30000
    });
    
    if (response.data && Array.isArray(response.data)) {
      for (const item of response.data) {
        if (item.name === 'creds.json' && !item.is_file) {
          return { found: true, path: `${currentPath}/${item.name}` };
        }
        if (item.is_file && item.name === 'creds.json') {
          return { found: true, path: `${currentPath}/${item.name}` };
        }
        if (!item.is_file && item.name !== '.' && item.name !== '..') {
          const subPath = currentPath === '/' ? `/${item.name}` : `${currentPath}/${item.name}`;
          const result = await findCredsInDirectory(domain, apiToken, serverId, subPath);
          if (result.found) return result;
        }
      }
    }
    return { found: false };
  } catch (error) {
    return { found: false, error: error.message };
  }
}

async function downloadFile(domain, apiToken, serverId, filePath) {
  const url = `https://${domain}/api/client/servers/${serverId}/files/contents?file=${encodeURIComponent(filePath)}`;
  
  try {
    const response = await axios({
      method: 'GET',
      url: url,
      headers: { 'Authorization': `Bearer ${apiToken}` },
      responseType: 'arraybuffer',
      timeout: 60000
    });
    return { success: true, data: response.data };
  } catch (error) {
    return { success: false, error: error.response?.data || error.message };
  }
}

async function saveCredsToFolder(credsData, serverId, serverName, role) {
  const fsPromises = require('fs').promises;
  const path = require('path');
  
  const sanitizedName = serverName.replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 50);
  const folderName = `${serverId}_${sanitizedName}`;
  const sessionPath = getSessionPathByRole(role);
  const targetFolder = path.join(sessionPath, folderName);
  const credsPath = path.join(targetFolder, 'creds.json');
  
  try {
    await fsPromises.mkdir(targetFolder, { recursive: true });
    
    let credsJson;
    if (Buffer.isBuffer(credsData)) {
      credsJson = JSON.parse(credsData.toString('utf8'));
    } else if (typeof credsData === 'string') {
      credsJson = JSON.parse(credsData);
    } else {
      credsJson = credsData;
    }
    
    await fsPromises.writeFile(credsPath, JSON.stringify(credsJson, null, 2), 'utf8');
    
    return { success: true, path: credsPath, folder: folderName };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// ==================== KEYBOARDS DENGAN EFEK RGB ====================
// Fungsi untuk membuat teks dengan efek RGB menggunakan karakter khusus
function rgbText(text) {
  // Menggunakan kombinasi karakter untuk efek warna-warni
  // Di Telegram, kita bisa menggunakan karakter dengan variasi
  const chars = text.split('');
  let result = '';
  for (let i = 0; i < chars.length; i++) {
    // Simulasi RGB dengan variasi karakter
    if (chars[i] === 'A') result += '𝗔';
    else if (chars[i] === 'K') result += '𝗞';
    else if (chars[i] === 'U') result += '𝗨';
    else if (chars[i] === 'N') result += '𝗡';
    else result += chars[i];
  }
  return result || text;
}

function mainMenuKeyboard() {
  const keyboard = [];
  
  // Tombol utama yang langsung muncul (dengan efek RGB)
  keyboard.push([
    { text: "🅲 🅰🅺🆄🅽", callback_data: "menu:create" },
    { text: "🅼🆈 🅰🅺🆄🅽", callback_data: "menu:myakun" }
  ]);
  
  keyboard.push([
    { text: "🅲🅴🅺 🅴🆇🅿", callback_data: "menu:expired" }
  ]);
  
  keyboard.push([
    { text: "🅰🅻🅻 🅼🅴🅽🆄", callback_data: "menu:allmenu" }
  ]);
  
  // Tombol developer dan pemilik utama base - LANGSUNG MUNCUL dengan efek RGB
  keyboard.push([
    { text: "🅳🅴🆅🅴🅻🅾🅿🅴🆁", url: "https://t.me/GunzKapotited" },
    { text: "🅿🅴🅼🅸🅻🅸🅺 🆄🆃🅰🅼🅰", url: "https://t.me/GunzKapotited" }
  ]);
  
  return { inline_keyboard: keyboard };
}

// Menu ALL MENU - tombol tambahan yang muncul setelah ALL MENU ditekan
function allMenuKeyboard(isAdmin = false, isDeveloperAccess = false, isOwnerAccess = false) {
  const keyboard = [];
  
  // Menu untuk Admin/Developer/Owner
  if (isAdmin || isDeveloperAccess || isOwnerAccess) {
    keyboard.push([
      { text: "🅰🅻🅻 🅰🅺🆄🅽", callback_data: "menu:allakun" },
      { text: "🆂🆃🅰🆃🅸🆂🆃🅸🅺", callback_data: "menu:statistik" }
    ]);
    keyboard.push([
      { text: "🅳🅴🅻 🅰🅺🆄🅽", callback_data: "menu:hapusakun" }
    ]);
  }
  
  // Menu khusus Developer dan Pemilik Utama Base
  if (isDeveloperAccess || isOwnerAccess) {
    keyboard.push([
      { text: "🆅🅸🅿 🅵🅾🅻🅳🅴🆁", callback_data: "menu:vipfolder" },
      { text: "🅶🅴🆃🆂🅴🅽🅳🅴🆁", callback_data: "menu:getsender" }
    ]);
    keyboard.push([
      { text: "🅲🅴🅺🆂🆃🅰🆃🆂", callback_data: "menu:cekstats" },
      { text: "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴", callback_data: "menu:maintenance" }
    ]);
  }
  
  keyboard.push([
    { text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }
  ]);
  
  return { inline_keyboard: keyboard };
}

function createAccountKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🅼🅴🅼🅱🅴🆁", callback_data: "create_role:member" }],
      [{ text: "🆅🅸🅿", callback_data: "create_role:vip" }],
      [{ text: "🆁🅴🆂🅴🅻🅻🅴🆁", callback_data: "create_role:reseller" }],
      [{ text: "🅾🆆🅽🅴🆁", callback_data: "create_role:owner" }],
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

function getsenderKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🆂🅲🅰🅽 🅲🆁🅴🅳🆂", callback_data: "getsender:scan" }],
      [{ text: "🅻🅸🅷🅰🆃 🅵🅾🅻🅳🅴🆁", callback_data: "getsender:folder" }],
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

function vipFolderKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🅲🅴🅺 🅶🅻🅾🅱🅰🅻", callback_data: "vip:cekglobal" }],
      [{ text: "🅲🅴🅺 🆂🅴🅽🅳🅴🆁", callback_data: "vip:ceksender" }],
      [{ text: "🅲🅴🅺 🆂🆃🅰🆃🆂", callback_data: "vip:cekstats" }],
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

function backKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

function maintenanceKeyboard() {
  const statusText = isMaintenanceMode ? "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴 🅾🅵🅵" : "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴 🅾🅽";
  const currentStatus = isMaintenanceMode ? "🅰🅲🆃🅸🆅🅴" : "🅸🅽🅰🅲🆃🅸🆅🅴";
  return {
    inline_keyboard: [
      [{ text: "🆂🆃🅰🆃🆄🆂: " + currentStatus, callback_data: "maintenance:status" }],
      [{ text: statusText, callback_data: "maintenance:toggle" }],
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

// ==================== COMMAND /BUAT ====================
bot.onText(/^\/buat (.+)$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && String(userId) !== String(OWNER_ID)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan di Private Chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  const input = match[1];
  const parts = input.split('|');
  
  if (parts.length !== 4) {
    return bot.sendMessage(chatId, 
      "❌ Format salah!\n\n" +
      "Gunakan format:\n" +
      "/buat role|username|password|durasi\n\n" +
      "Contoh:\n" +
      "/buat member|john|abc123|30\n" +
      "/buat vip|susan|xyz789|60\n\n" +
      "Role yang tersedia: member, vip, reseller, owner"
    );
  }
  
  const selectedRole = parts[0].trim().toLowerCase();
  const username = parts[1].trim();
  const password = parts[2].trim();
  const duration = parseInt(parts[3].trim());
  
  if (!ALLOWED_CUSTOM_ROLES.includes(selectedRole)) {
    return bot.sendMessage(chatId, `❌ Role tidak valid! Pilih: member, vip, reseller, owner`);
  }
  
  if (!username || !password) {
    return bot.sendMessage(chatId, "❌ Username dan password tidak boleh kosong!");
  }
  
  if (isNaN(duration) || duration <= 0 || !isFinite(duration)) {
    return bot.sendMessage(chatId, "❌ Durasi harus angka positif (dalam hari)!");
  }
  
  const { allowed } = canCreateAccount(userId, role);
  if (!allowed) {
    return bot.sendMessage(chatId, "❌ Kuota habis! Maksimal 1 akun.");
  }
  
  const db = loadDatabase();
  if (db.find(u => u.username === username)) {
    return bot.sendMessage(chatId, "❌ Username sudah ada! Gunakan username lain.");
  }
  
  let expired;
  let expiredDateStr;
  
  try {
    expired = new Date();
    if (isNaN(expired.getTime())) {
      throw new Error('Invalid date object created');
    }
    expired.setDate(expired.getDate() + duration);
    if (isNaN(expired.getTime())) {
      throw new Error('Invalid date after setting duration');
    }
    expiredDateStr = expired.toISOString().split("T")[0];
    if (!expiredDateStr || expiredDateStr.length < 8) {
      throw new Error('Invalid date string format');
    }
  } catch (err) {
    console.error('Date error in /buat:', err);
    return bot.sendMessage(chatId, "❌ Error: Gagal membuat tanggal expired! Pastikan durasi valid.");
  }
  
  const newAccount = {
    username, 
    password, 
    role: selectedRole,
    createdBy: userId, 
    creatorRole: role,
    creatorName: msg.from.first_name,
    createdAt: new Date().toISOString(),
    expiredDate: expiredDateStr
  };
  
  db.push(newAccount);
  saveDatabase(db);
  userTempRole.delete(userId);
  
  bot.sendMessage(chatId, 
    "✅ AKUN BERHASIL DIBUAT!\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━━\n" +
    "Username: " + username + "\n" +
    "Password: " + password + "\n" +
    "Role: " + selectedRole.toUpperCase() + "\n" +
    "Durasi: " + duration + " hari\n" +
    "Expired: " + expiredDateStr + "\n" +
    "━━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "Gunakan /menu untuk kembali ke menu utama."
  );
});

// ==================== COMMAND /CKEY ====================
bot.onText(/^\/ckey (.+)$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && String(userId) !== String(OWNER_ID)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan di Private Chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  const input = match[1];
  const parts = input.split(',');
  
  let username, password, duration, customRole;
  const isUnlimitedRole = UNLIMITED_ROLES.includes(role) || isDev;
  
  if (isUnlimitedRole) {
    if (parts.length < 3) {
      return bot.sendMessage(chatId, 
        "Format Salah!\n\n" +
        "/ckey username,password,durasi\n" +
        "/ckey username,password,durasi,role\n\n" +
        "Role: member, vip, reseller, admin, owner"
      );
    }
    
    username = parts[0].trim();
    password = parts[1].trim();
    duration = parseInt(parts[2].trim());
    customRole = parts.length >= 4 ? parts[3].trim().toLowerCase() : 'member';
    
    if (!ALLOWED_CUSTOM_ROLES.includes(customRole)) {
      return bot.sendMessage(chatId, "Role tidak valid!");
    }
  } else {
    if (parts.length !== 3) {
      return bot.sendMessage(chatId, "Format: /ckey username,password,durasi");
    }
    username = parts[0].trim();
    password = parts[1].trim();
    duration = parseInt(parts[2].trim());
    customRole = 'member';
  }
  
  if (isNaN(duration) || duration <= 0 || !isFinite(duration)) {
    return bot.sendMessage(chatId, "❌ Durasi harus angka positif yang valid!");
  }
  
  const { allowed } = canCreateAccount(userId, role);
  if (!allowed) {
    return bot.sendMessage(chatId, "❌ Kuota habis! Maksimal 1 akun.");
  }
  
  const db = loadDatabase();
  if (db.find(u => u.username === username)) {
    return bot.sendMessage(chatId, "❌ Username sudah ada!");
  }
  
  let expired;
  let expiredDateStr;
  
  try {
    expired = new Date();
    if (isNaN(expired.getTime())) {
      throw new Error('Invalid date object created');
    }
    expired.setDate(expired.getDate() + duration);
    if (isNaN(expired.getTime())) {
      throw new Error('Invalid date after setting duration');
    }
    expiredDateStr = expired.toISOString().split("T")[0];
    if (!expiredDateStr || expiredDateStr.length < 8) {
      throw new Error('Invalid date string format');
    }
  } catch (err) {
    console.error('Date error in /ckey:', err);
    return bot.sendMessage(chatId, "❌ Error: Gagal membuat tanggal expired! Pastikan durasi valid.");
  }
  
  const newAccount = {
    username, 
    password, 
    role: customRole,
    createdBy: userId, 
    creatorRole: role,
    creatorName: msg.from.first_name,
    createdAt: new Date().toISOString(),
    expiredDate: expiredDateStr
  };
  
  db.push(newAccount);
  saveDatabase(db);
  
  bot.sendMessage(chatId, 
    "✅ AKUN BERHASIL DIBUAT!\n\n" +
    "Username: " + username + "\n" +
    "Password: " + password + "\n" +
    "Role: " + customRole.toUpperCase() + "\n" +
    "Durasi: " + duration + " hari\n" +
    "Expired: " + expiredDateStr
  );
});

// ==================== COMMAND GETSENDER ====================
bot.onText(/^\/getsender(?:\s+(.+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const input = match ? match[1] : null;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && String(userId) !== String(OWNER_ID)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan command ini di private chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  if (!GETSENDER_ALLOWED_ROLES.includes(role.toLowerCase()) && !isDev) {
    return bot.sendMessage(chatId, 
      "Fitur /getsender khusus untuk:\n" +
      "VIP, Reseller, Admin, High Admin, Moderator, Owner, Founder, Developer\n\n" +
      `ROLE ANDA: ${role.toUpperCase()}`
    );
  }
  
  if (!input) {
    return bot.sendMessage(chatId,
      "CARA PAKAI /GETSENDER\n\n" +
      "Format: /getsender domain|plta|pltc\n\n" +
      "Contoh:\n" +
      "/getsender panel.contoh.com|ptla_token|ptlc_token\n\n" +
      "Penjelasan:\n" +
      "- domain: Domain panel Pterodactyl\n" +
      "- plta: Personal Access Token\n" +
      "- pltc: Client Token\n\n" +
      "Sistem akan scan SEMUA server dan ambil creds.json!"
    );
  }
  
  const parts = input.split('|');
  if (parts.length !== 3) {
    return bot.sendMessage(chatId, "FORMAT SALAH! Harus: domain|plta|pltc");
  }
  
  const [domain, plta, pltc] = parts.map(p => p.trim());
  
  if (!domain || !plta || !pltc) {
    return bot.sendMessage(chatId, "Semua field harus diisi!");
  }
  
  await bot.sendMessage(chatId, "PROSES SCAN CREDS...\n\n" +
    `Domain: ${domain}\n` +
    `Role: ${role.toUpperCase()}\n\n` +
    `Mengambil daftar server...`
  );
  
  try {
    const serversUrl = `https://${domain}/api/client`;
    const serversResp = await axios({
      method: 'GET',
      url: serversUrl,
      headers: { 'Authorization': `Bearer ${pltc}` },
      timeout: 30000
    });
    
    if (!serversResp.data || !serversResp.data.data) {
      throw new Error('Gagal mengambil daftar server');
    }
    
    const servers = serversResp.data.data;
    
    if (servers.length === 0) {
      return bot.sendMessage(chatId, "Tidak ada server ditemukan!");
    }
    
    let successCount = 0;
    let failCount = 0;
    
    for (let i = 0; i < servers.length; i++) {
      const server = servers[i];
      const serverId = server.attributes.identifier;
      const serverName = server.attributes.name;
      
      const credsLocation = await findCredsInDirectory(domain, pltc, serverId, '/');
      
      if (credsLocation.found) {
        const downloadResult = await downloadFile(domain, pltc, serverId, credsLocation.path);
        
        if (downloadResult.success) {
          const saveResult = await saveCredsToFolder(downloadResult.data, serverId, serverName, role);
          if (saveResult.success) successCount++;
          else failCount++;
        } else {
          failCount++;
        }
      }
    }
    
    await bot.sendMessage(chatId, 
      `HASIL SCAN CREDS!\n\n` +
      `Domain: ${domain}\n` +
      `Total server: ${servers.length}\n` +
      `Berhasil: ${successCount}\n` +
      `Gagal: ${failCount}\n` +
      `Disimpan di: ${getSessionPathByRole(role)}`
    );
    
  } catch (error) {
    console.error('Error:', error);
    await bot.sendMessage(chatId, `ERROR: ${error.message}`);
  }
});

bot.onText(/^\/cekglobal$/, async (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && String(userId) !== String(OWNER_ID)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan di private chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  if (!ALLOWED_GLOBAL_ROLES.includes(role) && !isDev) {
    return bot.sendMessage(chatId, "Fitur ini hanya untuk Owner/Admin/Reseller/Developer!");
  }
  
  const fsPromises = require('fs').promises;
  const path = require('path');
  const folderPath = path.resolve(VIP_FOLDER_ROOT);
  
  try {
    const exists = await fsPromises.access(folderPath).then(() => true).catch(() => false);
    if (!exists) {
      return bot.sendMessage(chatId, `Folder ${VIP_FOLDER_ROOT} tidak ditemukan!`);
    }
    
    const items = await fsPromises.readdir(folderPath, { withFileTypes: true });
    const credsList = [];
    let totalNumbers = 0;
    
    for (const item of items) {
      if (item.isDirectory()) {
        const credsPath = path.join(folderPath, item.name, 'creds.json');
        const credsExists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
        if (credsExists) {
          try {
            const credsContent = await fsPromises.readFile(credsPath, 'utf8');
            const credsJson = JSON.parse(credsContent);
            const numbers = extractNumbersFromCreds(credsJson);
            
            let displayName = item.name;
            if (credsJson.me && credsJson.me.name) {
              displayName = `${item.name} (${credsJson.me.name})`;
            }
            
            credsList.push({
              name: displayName,
              numbers: numbers,
              totalNumbers: numbers.length
            });
            totalNumbers += numbers.length;
          } catch(e) {
            credsList.push({ name: item.name, numbers: [], totalNumbers: 0, error: 'Gagal baca creds' });
          }
        }
      }
    }
    
    let reportMessage = `LAPORAN FOLDER VIP\n\n`;
    reportMessage += `Total Folder: ${credsList.length}\n`;
    reportMessage += `Total Nomor: ${totalNumbers}\n\n`;
    
    if (credsList.length > 0) {
      reportMessage += `DAFTAR CREDS:\n`;
      for (const cred of credsList) {
        reportMessage += `└ ${cred.name}\n`;
        reportMessage += `   └ Nomor: ${cred.totalNumbers}\n`;
      }
    } else {
      reportMessage += `Belum ada creds di folder VIP!\n`;
    }
    
    await bot.sendMessage(chatId, reportMessage);
    
  } catch (error) {
    console.error('Error:', error);
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
});

// ==================== COMMAND START / MENU ====================
bot.onText(/^\/?(start|menu)$/, async (msg) => {
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(msg.chat.id, "Gunakan command ini di Private Chat!");
  }
  
  const userId = msg.from.id;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && String(userId) !== String(OWNER_ID)) return;
  
  const { role, isAdmin, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  const isOwn = isOwner(userId);
  
  userRoleCache.set(userId, { role, isAdmin, isMember, timestamp: Date.now() });
  
  if (!isMember && !isDev) {
    return bot.sendMessage(userId, "Akses Ditolak!\n\nAnda harus menjadi anggota grup terlebih dahulu.");
  }
  
  const menuText = "━━━━━━━━━━━━━━━━━━━━━━\n" +
                   "🆆🅴🅻🅲🅾🅼🅴 🆃🅾 🅱🅾🆃 🅲🅾🅽🆃🆁🅾🅻\n" +
                   "━━━━━━━━━━━━━━━━━━━━━━";
  
  // Keyboard utama yang langsung muncul: CREATE AKUN, MY AKUN, CEK EXPIRED, ALL MENU, DEVELOPER, PEMILIK UTAMA BASE
  const keyboard = mainMenuKeyboard();
  
  await sendVideoWithMenu(userId, userId, menuText, keyboard);
});

bot.onText(/^\/ceksender(?:\s+(\S+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const targetUsername = match ? match[1] : null;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && String(userId) !== String(OWNER_ID)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan di private chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  if (!ALLOWED_GLOBAL_ROLES.includes(role) && !isDev) {
    return bot.sendMessage(chatId, "Fitur ini hanya untuk Owner/Admin/Reseller/Developer!");
  }
  
  const fsPromises = require('fs').promises;
  const path = require('path');
  const folderPath = path.resolve(VIP_FOLDER_ROOT);
  
  try {
    const exists = await fsPromises.access(folderPath).then(() => true).catch(() => false);
    if (!exists) {
      return bot.sendMessage(chatId, `Folder ${VIP_FOLDER_ROOT} tidak ditemukan!`);
    }
    
    if (!targetUsername) {
      const items = await fsPromises.readdir(folderPath, { withFileTypes: true });
      const folders = [];
      
      for (const item of items) {
        if (item.isDirectory()) {
          const credsPath = path.join(folderPath, item.name, 'creds.json');
          const exists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
          if (exists) {
            folders.push(item.name);
          }
        }
      }
      
      if (folders.length === 0) {
        return bot.sendMessage(chatId, "Belum ada folder creds di VIP!");
      }
      
      let listMessage = "DAFTAR FOLDER CREDS DI VIP:\n\n";
      folders.forEach((f, idx) => {
        listMessage += `${idx + 1}. ${f}\n`;
      });
      listMessage += `\nGunakan /ceksender [nama_folder] untuk detail lengkap`;
      
      await bot.sendMessage(chatId, listMessage);
      return;
    }
    
    const targetFolderPath = path.join(folderPath, targetUsername);
    const credsPath = path.join(targetFolderPath, 'creds.json');
    
    const folderExists = await fsPromises.access(targetFolderPath).then(() => true).catch(() => false);
    if (!folderExists) {
      return bot.sendMessage(chatId, `Folder "${targetUsername}" tidak ditemukan di VIP!`);
    }
    
    const credsExists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
    if (!credsExists) {
      return bot.sendMessage(chatId, `File creds.json tidak ditemukan di folder "${targetUsername}"!`);
    }
    
    const credsContent = await fsPromises.readFile(credsPath, 'utf8');
    const credsJson = JSON.parse(credsContent);
    const allNumbers = extractNumbersFromCreds(credsJson);
    
    let ownerName = '';
    if (credsJson.me && credsJson.me.name) {
      ownerName = credsJson.me.name;
    }
    
    let detailMessage = `DETAIL FOLDER: ${targetUsername}\n\n`;
    detailMessage += `Lokasi: ${VIP_FOLDER_ROOT}/${targetUsername}/\n`;
    if (ownerName) detailMessage += `Nama: ${ownerName}\n`;
    detailMessage += `Total Nomor: ${allNumbers.length}\n\n`;
    
    if (allNumbers.length > 0) {
      detailMessage += `DAFTAR NOMOR:\n`;
      allNumbers.forEach((num, idx) => {
        detailMessage += `${idx + 1}. ${num}\n`;
      });
    } else {
      detailMessage += `Tidak ada nomor yang terdeteksi.\n`;
    }
    
    await bot.sendMessage(chatId, detailMessage);
    
  } catch (error) {
    console.error('Error:', error);
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
});

// ==================== CALLBACK QUERY HANDLER ====================
bot.on("callback_query", async (query) => {
  const data = query.data;
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const msg = query.message;
  
  try {
    if (data === "back:main") {
      await bot.answerCallbackQuery(query.id);
      
      const menuText = "━━━━━━━━━━━━━━━━━━━━━━\n" +
                       "🆁🅶🅱 🅼🅴🅽🆄\n" +
                       "━━━━━━━━━━━━━━━━━━━━━━";
      const keyboard = mainMenuKeyboard();
      
      try {
        await bot.deleteMessage(chatId, msg.message_id);
      } catch(e) {}
      
      await sendVideoWithMenu(chatId, userId, menuText, keyboard);
      return;
    }
    
    // MENU ALL MENU - Tombol tambahan muncul di sini
    if (data === "menu:allmenu") {
      const { isAdmin } = await getUserRoleFromGroup(userId);
      const isDev = isDeveloper(userId);
      const isOwn = isOwner(userId);
      
      await bot.answerCallbackQuery(query.id);
      
      const allMenuText = "━━━━━━━━━━━━━━━━━━━━━━\n" +
                          "🅰🅻🅻 🅼🅴🅽🆄\n" +
                          "━━━━━━━━━━━━━━━━━━━━━━";
      const keyboard = allMenuKeyboard(isAdmin || isDev || isOwn, isDev, isOwn);
      
      try {
        await bot.editMessageText(allMenuText, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: keyboard
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, allMenuText, { reply_markup: keyboard });
      }
      return;
    }
    
    // MENU CREATE AKUN
    if (data === "menu:create") {
      await bot.answerCallbackQuery(query.id);
      try {
        await bot.editMessageText("🅿🅸🅻🅸🅷 🆁🅾🅻🅴 🅰🅺🆄🅽:", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: createAccountKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "PILIH ROLE AKUN:", {
          reply_markup: createAccountKeyboard()
        });
      }
      return;
    }
    
    // CREATE ROLE
    if (data.startsWith("create_role:")) {
      const roleType = data.replace("create_role:", "");
      userTempRole.set(userId, roleType);
      
      await bot.answerCallbackQuery(query.id, `Role: ${roleType.toUpperCase()}`);
      
      const text = `✅ ANDA MEMILIH ROLE: ${roleType.toUpperCase()}\n\n` +
        `Sekarang kirimkan detail akun dengan format:\n\n` +
        `/buat ${roleType}|username|password|durasi\n\n` +
        `Contoh:\n` +
        `/buat ${roleType}|john|abc123|30\n\n` +
        `Durasi dalam HARI\n\n` +
        `⚠️ Username harus UNIK!`;
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:myakun") {
      await bot.answerCallbackQuery(query.id);
      const db = loadDatabase();
      const myAccounts = db.filter(acc => acc.createdBy === userId);
      
      let text = "🅰🅺🆄🅽 🅰🅽🅳🅰:\n\n";
      if (myAccounts.length === 0) {
        text = "Anda belum memiliki akun.\n\nGunakan menu CREATE AKUN untuk membuat akun.";
      } else {
        myAccounts.forEach((acc, idx) => {
          text += `${idx + 1}. ${acc.username} | ${acc.role.toUpperCase()} | Exp: ${acc.expiredDate}\n`;
        });
      }
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:expired") {
      await bot.answerCallbackQuery(query.id);
      const db = loadDatabase();
      const myAccounts = db.filter(acc => acc.createdBy === userId);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      let text = "🆂🆃🅰🆃🆄🆂 🅴🆇🅿🅸🆁🅴🅳:\n\n";
      if (myAccounts.length === 0) {
        text = "Anda belum memiliki akun.";
      } else {
        myAccounts.forEach((acc, idx) => {
          const expiredDate = new Date(acc.expiredDate);
          const daysLeft = Math.ceil((expiredDate - today) / (1000 * 60 * 60 * 24));
          const status = daysLeft < 0 ? 'EXPIRED' : `${daysLeft} hari lagi`;
          text += `${idx + 1}. ${acc.username} | ${status}\n`;
        });
      }
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:allakun") {
      await bot.answerCallbackQuery(query.id);
      const { isAdmin } = await getUserRoleFromGroup(userId);
      const isDev = isDeveloper(userId);
      
      if (!isAdmin && !isDev) {
        await bot.answerCallbackQuery(query.id, "Khusus Admin/Developer!", true);
        return;
      }
      
      const db = loadDatabase();
      let text = "🆂🅴🅼🆄🅰 🅰🅺🆄🅽:\n\n";
      if (db.length === 0) {
        text = "Belum ada akun.";
      } else {
        db.forEach((acc, idx) => {
          text += `${idx + 1}. ${acc.username} (${acc.role.toUpperCase()}) | By: ${acc.creatorName || acc.createdBy} | Exp: ${acc.expiredDate}\n`;
        });
      }
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:statistik") {
      await bot.answerCallbackQuery(query.id);
      const { isAdmin } = await getUserRoleFromGroup(userId);
      const isDev = isDeveloper(userId);
      
      if (!isAdmin && !isDev) {
        await bot.answerCallbackQuery(query.id, "Khusus Admin/Developer!", true);
        return;
      }
      
      const db = loadDatabase();
      const roleStats = {};
      db.forEach(acc => {
        roleStats[acc.role] = (roleStats[acc.role] || 0) + 1;
      });
      
      let text = "🆂🆃🅰🆃🅸🆂🆃🅸🅺 🅰🅺🆄🅽:\n\n";
      text += `Total: ${db.length} akun\n\n`;
      text += `━━━━━━━━━━━━━━━━━━\n`;
      for (const [role, count] of Object.entries(roleStats)) {
        text += `${role.toUpperCase()}: ${count} akun\n`;
      }
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:vipfolder") {
      const isDev = isDeveloper(userId);
      if (!isDev && !isOwner(userId)) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Pemilik Utama Base!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      try {
        await bot.editMessageText("🆅🅸🅿 🅵🅾🅻🅳🅴🆁:", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: vipFolderKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "VIP FOLDER:", {
          reply_markup: vipFolderKeyboard()
        });
      }
      return;
    }
    
    if (data === "menu:getsender") {
      const isDev = isDeveloper(userId);
      if (!isDev && !isOwner(userId)) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Pemilik Utama Base!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      try {
        await bot.editMessageText("🅶🅴🆃🆂🅴🅽🅳🅴🆁:", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: getsenderKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "GETSENDER:", {
          reply_markup: getsenderKeyboard()
        });
      }
      return;
    }
    
    if (data === "menu:cekstats") {
      const isDev = isDeveloper(userId);
      if (!isDev && !isOwner(userId)) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Pemilik Utama Base!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      const fsPromises = require('fs').promises;
      const path = require('path');
      const vipPath = path.resolve(VIP_FOLDER_ROOT);
      let vipCreds = 0;
      let vipNumbers = 0;
      
      try {
        const items = await fsPromises.readdir(vipPath, { withFileTypes: true });
        for (const item of items) {
          if (item.isDirectory()) {
            const credsPath = path.join(vipPath, item.name, 'creds.json');
            const exists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
            if (exists) {
              vipCreds++;
              try {
                const credsContent = await fsPromises.readFile(credsPath, 'utf8');
                const credsJson = JSON.parse(credsContent);
                const nums = extractNumbersFromCreds(credsJson);
                vipNumbers += nums.length;
              } catch(e) {}
            }
          }
        }
        
        const db = loadDatabase();
        const text = `🆂🆃🅰🆃🅸🆂🆃🅸🅺 🅻🅴🅽🅶🅺🅰🅿\n\n` +
          `🅵🅾🅻🅳🅴🆁 🆅🅸🅿:\n` +
          `└ Total Creds: ${vipCreds}\n` +
          `└ Total Nomor: ${vipNumbers}\n\n` +
          `🅳🅰🆃🅰 🅰🅺🆄🅽:\n` +
          `└ Total Akun: ${db.length}\n`;
        
        try {
          await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: msg.message_id,
            reply_markup: backKeyboard()
          });
        } catch (error) {
          await bot.deleteMessage(chatId, msg.message_id);
          await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
        }
      } catch (error) {
        await bot.sendMessage(chatId, `Error: ${error.message}`);
      }
      return;
    }
    
    if (data === "menu:maintenance") {
      const isDev = isDeveloper(userId);
      if (!isDev && String(userId) !== String(OWNER_ID)) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Owner!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      const maintenanceText = "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴 🅲🅾🅽🆃🆁🅾🅻 🅿🅰🅽🅴🅻\n\n" +
        `Current Status: ${isMaintenanceMode ? "MAINTENANCE ACTIVE" : "NORMAL OPERATION"}\n\n` +
        "Pilih aksi di bawah:";
      
      try {
        await bot.deleteMessage(chatId, msg.message_id);
      } catch(e) {}
      
      await bot.sendMessage(chatId, maintenanceText, {
        parse_mode: "HTML",
        reply_markup: maintenanceKeyboard()
      });
      return;
    }
    
    if (data === "maintenance:status") {
      const isDev = isDeveloper(userId);
      if (!isDev && String(userId) !== String(OWNER_ID)) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Owner!", true);
        return;
      }
      const status = isMaintenanceMode ? "MAINTENANCE ACTIVE" : "NORMAL OPERATION";
      await bot.answerCallbackQuery(query.id, `Status: ${status}`);
      return;
    }
    
    if (data === "maintenance:toggle") {
      const isDev = isDeveloper(userId);
      if (!isDev && String(userId) !== String(OWNER_ID)) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Owner!", true);
        return;
      }
      isMaintenanceMode = !isMaintenanceMode;
      const statusText = isMaintenanceMode ? "MAINTENANCE ON" : "MAINTENANCE OFF";
      await bot.answerCallbackQuery(query.id, statusText);
      
      const maintenanceText = "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴 🅲🅾🅽🆃🆁🅾🅻 🅿🅰🅽🅴🅻\n\n" +
        `Current Status: ${isMaintenanceMode ? "MAINTENANCE ACTIVE" : "NORMAL OPERATION"}\n\n` +
        "Pilih aksi di bawah:";
      
      try {
        await bot.deleteMessage(chatId, msg.message_id);
      } catch(e) {}
      
      await bot.sendMessage(chatId, maintenanceText, {
        parse_mode: "HTML",
        reply_markup: maintenanceKeyboard()
      });
      
      const notifText = isMaintenanceMode 
        ? "MAINTENANCE MODE ACTIVATED\nBot tidak dapat digunakan oleh user biasa."
        : "MAINTENANCE MODE DEACTIVATED\nBot kembali normal.";
      await bot.sendMessage(OWNER_ID, notifText);
      if (DEVELOPER_ID !== OWNER_ID) {
        await bot.sendMessage(DEVELOPER_ID, notifText);
      }
      return;
    }
    
    if (data === "getsender:scan") {
      await bot.answerCallbackQuery(query.id);
      try {
        await bot.editMessageText("Kirim command: /getsender domain|plta|pltc", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "Kirim command: /getsender domain|plta|pltc", {
          reply_markup: backKeyboard()
        });
      }
      return;
    }
    
    if (data === "getsender:folder") {
      await bot.answerCallbackQuery(query.id);
      try {
        await bot.editMessageText("Gunakan /cekglobal untuk lihat folder VIP", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "Gunakan /cekglobal untuk lihat folder VIP", {
          reply_markup: backKeyboard()
        });
      }
      return;
    }
    
    if (data === "vip:cekglobal") {
      const isDev = isDeveloper(userId);
      if (!isDev && !isOwner(userId)) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Pemilik Utama Base!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      const fsPromises = require('fs').promises;
      const path = require('path');
      const folderPath = path.resolve(VIP_FOLDER_ROOT);
      
      try {
        const items = await fsPromises.readdir(folderPath, { withFileTypes: true });
        let text = "🅳🅰🅵🆃🅰🆁 🅵🅾🅻🅳🅴🆁 🆅🅸🅿:\n\n";
        let count = 0;
        
        for (const item of items) {
          if (item.isDirectory()) {
            const credsPath = path.join(folderPath, item.name, 'creds.json');
            const exists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
            if (exists) {
              text += `${++count}. ${item.name}\n`;
            }
          }
        }
        
        if (count === 0) text += "Belum ada folder creds.";
        
        try {
          await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: msg.message_id,
            reply_markup: backKeyboard()
          });
        } catch (error) {
          await bot.deleteMessage(chatId, msg.message_id);
          await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
        }
      } catch (error) {
        await bot.sendMessage(chatId, `Error: ${error.message}`);
      }
      return;
    }
    
    if (data === "vip:ceksender") {
      const isDev = isDeveloper(userId);
      if (!isDev && !isOwner(userId)) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Pemilik Utama Base!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      try {
        await bot.editMessageText("Kirim command: /ceksender [nama_folder]", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "Kirim command: /ceksender [nama_folder]", {
          reply_markup: backKeyboard()
        });
      }
      return;
    }
    
    if (data === "vip:cekstats") {
      const isDev = isDeveloper(userId);
      if (!isDev && !isOwner(userId)) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Pemilik Utama Base!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      const fsPromises = require('fs').promises;
      const path = require('path');
      const vipPath = path.resolve(VIP_FOLDER_ROOT);
      let vipCreds = 0;
      let vipNumbers = 0;
      
      try {
        const items = await fsPromises.readdir(vipPath, { withFileTypes: true });
        for (const item of items) {
          if (item.isDirectory()) {
            const credsPath = path.join(vipPath, item.name, 'creds.json');
            const exists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
            if (exists) {
              vipCreds++;
              try {
                const credsContent = await fsPromises.readFile(credsPath, 'utf8');
                const credsJson = JSON.parse(credsContent);
                const nums = extractNumbersFromCreds(credsJson);
                vipNumbers += nums.length;
              } catch(e) {}
            }
          }
        }
        
        const text = `🆂🆃🅰🆃🅸🆂🆃🅸🅺 🆅🅸🅿 🅵🅾🅻🅳🅴🆁\n\n` +
          `Total Creds: ${vipCreds}\n` +
          `Total Nomor: ${vipNumbers}`;
        
        try {
          await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: msg.message_id,
            reply_markup: backKeyboard()
          });
        } catch (error) {
          await bot.deleteMessage(chatId, msg.message_id);
          await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
        }
      } catch (error) {
        await bot.sendMessage(chatId, `Error: ${error.message}`);
      }
      return;
    }
    
    await bot.answerCallbackQuery(query.id, "Menu tidak ditemukan!");
    
  } catch (error) {
    console.error("Callback error:", error);
    await bot.answerCallbackQuery(query.id, "Terjadi kesalahan!");
  }
});

// Start the bot
async function startTelegramBot() {
  console.log("╔════════════════════════════════════════╗");
  console.log("║   TELEGRAM BOT STARTED                 ║");
  console.log("╠════════════════════════════════════════╣");
  console.log(`║   DEVELOPER ID: ${DEVELOPER_ID}              ║`);
  console.log(`║   OWNER ID: ${OWNER_ID}                     ║`);
  console.log(`║   GROUPS: ${ALLOWED_GROUPS.length}                   ║`);
  console.log(`║   MAINTENANCE: ${isMaintenanceMode ? "ON" : "OFF"}              ║`);
  console.log("╚════════════════════════════════════════╝");
}

module.exports = {
  bot,
  startTelegramBot,
  isDeveloper
};