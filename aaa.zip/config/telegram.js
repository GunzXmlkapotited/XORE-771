module.exports = {
  TOKEN: process.env.TELEGRAM_TOKEN || "8307787706:AAHwsewuisllKa9gTjcO3t5cw2T_z1G7HLI",
  OWNER_ID: process.env.OWNER_ID || 8212614573,
  ID_GROUP: [
    -1003941541137
  ],
  ID_GROUP_UTAMA: [
    -1003941541137
  ]
};