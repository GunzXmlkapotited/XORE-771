// config.js atau langsung di script
window.API_URL = (window.location.hostname === "localhost" || 
                  window.location.hostname === "127.0.0.1")
    ? "http://localhost:3000"  // Development
    : "https://portfolio-gunz.xonepanel.qzz.io";  // Production